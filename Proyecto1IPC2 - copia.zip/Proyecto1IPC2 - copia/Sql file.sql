-- -----------------------------------------------------
-- Schema tienda
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `tienda` DEFAULT CHARACTER SET utf8 ;
USE `tienda` ;

-- -----------------------------------------------------
-- Table `tienda`.`tiendas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`tiendas` (
  `Codigo` BIGINT NOT NULL,
  `Direccion` VARCHAR(45) NOT NULL,
  `Tipo` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`Codigo`),
  UNIQUE INDEX `Codigo_UNIQUE` (`Codigo` ASC) VISIBLE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `tienda`.`usuariosadministradores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`usuariosadministradores` (
  `Codigo` BIGINT NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `NombreUsuario` VARCHAR(45) NOT NULL,
  `Contraseña` VARCHAR(40) NOT NULL,
  PRIMARY KEY (`Codigo`),
  UNIQUE INDEX `Codigo_UNIQUE` (`Codigo` ASC) VISIBLE)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `tienda`.`usuariossupervisor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`usuariossupervisor` (
  `Codigo` BIGINT NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `NombreUsuario` VARCHAR(45) NOT NULL,
  `Contraseña` VARCHAR(40) NOT NULL,
  `CorreoElectronico` VARCHAR(50) NOT NULL,
  `TiendasSupervisadas` VARCHAR(100) NULL,
  PRIMARY KEY (`Codigo`),
  UNIQUE INDEX `Codigo_UNIQUE` (`Codigo` ASC) VISIBLE)
ENGINE = InnoDB

-- -----------------------------------------------------
-- Table `tienda`.`usuariosbodega`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`usuariosbodega` (
  `Codigo` BIGINT NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `NombreUsuario` VARCHAR(45) NOT NULL,
  `Contraseña` VARCHAR(40) NOT NULL,
  `CorreoElectronico` VARCHAR(50) NOT NULL,
  `TiendasSupervisadas` VARCHAR(100) NULL,
  PRIMARY KEY (`Codigo`),
  UNIQUE INDEX `Codigo_UNIQUE` (`Codigo` ASC) VISIBLE)
ENGINE = InnoDB

-- -----------------------------------------------------
-- Table `tienda`.`usuariostienda`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`usuariostienda` (
  `Codigo` BIGINT NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `NombreUsuario` VARCHAR(45) NOT NULL,
  `Contraseña` VARCHAR(40) NOT NULL,
  `CorreoElectronico` VARCHAR(50) NOT NULL,
  `Tienda` BIGINT NOT NULL,
  PRIMARY KEY (`Codigo`),
  UNIQUE INDEX `Codigo_UNIQUE` (`Codigo` ASC) VISIBLE)
ENGINE = InnoDB

-- -----------------------------------------------------
-- Table `tienda`.`catalogobodega`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`catalogobodega` (
  `CodigoProducto` BIGINT NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `Costo` DOUBLE NOT NULL,
  `Precio` DOUBLE NOT NULL,
  `Existencias` BIGINT NOT NULL,
  PRIMARY KEY (`CodigoProducto`),
  UNIQUE INDEX `CodigoProducto_UNIQUE` (`CodigoProducto` ASC) VISIBLE)
ENGINE = InnoDB

-- -----------------------------------------------------
-- Table `tienda`.`catalogos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`catalogos` (
  `Tienda` VARCHAR(45) NOT NULL,
  `Productos` VARCHAR(500)  NOT NULL
  PRIMARY KEY (`Tienda`),
  UNIQUE INDEX `Tienda_UNIQUE` (`Tienda` ASC) VISIBLE)
  
ENGINE = InnoDB

-- -----------------------------------------------------
-- Table `tienda`.`pedidos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`pedidos` (
  `id` BIGINT NOT NULL,
  `tienda` BIGINT NOT NULL,
  `fecha` DATE NOT NULL,
  `productos` VARCHAR(200) NOT NULL,
  `estado` VARCHAR(10) NOT NULL,
  `total` Double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE)
ENGINE = InnoDB

-- -----------------------------------------------------
-- Table `tienda`.`envios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`envios` (
  `id` BIGINT NOT NULL,
  `pedido` BIGINT NOT NULL,
  `tienda` BIGINT NOT NULL,
  `fechasalida` DATE NOT NULL,
  `fecharecibida` DATE NOT NULL,
  `productos` VARCHAR(200) NOT NULL,
  `estado` VARCHAR(20) NOT NULL,
  `total` Double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE)
ENGINE = InnoDB

-- -----------------------------------------------------
-- Table `tienda`.`incidencias`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `tienda`.`incidencias` (
  `id` BIGINT NOT NULL,
  `envio` BIGINT NOT NULL,
  `tienda` BIGINT NOT NULL,
  `fecha` DATE NOT NULL,
  `productos` VARCHAR(200) NOT NULL,
  `estado` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE)
ENGINE = InnoDB