/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "AgregarCantidad", urlPatterns = "/AgregarCantidad")
public class AgregarCantidadReporte extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        String Nombre = request.getParameter("usuario");
        String cantidad = request.getParameter("cantidad");
        
        response.sendRedirect(String.format("JSP/ReportesProductosTienda.jsp?usuario="+Nombre+"&cantidad="+cantidad));
        
    }
    
}
