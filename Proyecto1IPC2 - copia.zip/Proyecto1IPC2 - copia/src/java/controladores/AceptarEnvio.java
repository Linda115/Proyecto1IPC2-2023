/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "AceptarEnvio", urlPatterns = "/AceptarEnvio")
public class AceptarEnvio extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
        String usuario = request.getParameter("usuario");
        String Productos = request.getParameter("Productos");
        int id = Integer.parseInt(request.getParameter("ids"));
        
        try {
            response.sendRedirect(String.format("JSP/RespuestaTienda.jsp?result=%s&usuario="+usuario, RegistrarEnvio.RegistrarEnvios(Productos, BuscarDB.BuscarTiendaDeUsuario(usuario))&&Escritor.CAmbiarEstadoEnvio(id)));
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(AceptarEnvio.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
