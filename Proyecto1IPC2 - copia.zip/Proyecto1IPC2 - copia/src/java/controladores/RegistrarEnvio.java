/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Modelos.ProductoAgregar;
import Modelos.Productos;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Linda Monterroso
 */
public class RegistrarEnvio {
    
    public static boolean RegistrarEnvios(String Productos, int tienda) throws ClassNotFoundException{
        String productosTienda = BuscarDB.getCatalogo(tienda);
        ArrayList<ProductoAgregar> nuevo = NuevaCadena(getArreglo(productosTienda), getArreglo(Productos));
        
        String ProductosNuevosTienda =Cadena(nuevo);
        
        return Escritor.EditarCatalogo(tienda, ProductosNuevosTienda);
    }
    
    private static ArrayList<ProductoAgregar> getArreglo(String Productos){
        
        if(Productos!=null){
            String[] productos = Productos.split(",");
            HashMap<String, String> ProductosLista = new HashMap<String, String>();
            for(int x=0; x<productos.length; x++){
                System.out.println(productos[x]);
                String[] productosCantidades = productos[x].split(":");
                if(productosCantidades.length>1){
                    System.out.println(productosCantidades[0]);
                    ProductosLista.put(productosCantidades[0], productosCantidades[1]);
                }
            }
            ArrayList<ProductoAgregar> ProductosEnvio = new ArrayList<>();
            ProductoAgregar producto;
            System.out.println(ProductosLista);
            for (Map.Entry<String, String> entry : ProductosLista.entrySet()) {
                System.out.println(entry.getKey()+entry.getValue()+" Nombre Producto/n");
                producto = new ProductoAgregar(entry.getKey(),Integer.parseInt(entry.getValue()));
                ProductosEnvio.add(producto);
            }
            return ProductosEnvio;
        }
        return null;
    }
    
    private static ArrayList<ProductoAgregar> NuevaCadena(ArrayList<ProductoAgregar> catalogo, ArrayList<ProductoAgregar> agregar){
        ArrayList<ProductoAgregar> nuevo = new ArrayList<>();
        for(ProductoAgregar producto1: catalogo ){
            for (ProductoAgregar producto2: agregar){
                if(producto1.equals(producto2)){
                   producto1.setCantidad(producto1.getCantidad()+producto2.getCantidad());
                }
                
            }
           nuevo.add(producto1);
        }
        
        return nuevo;
    }

    private static String Cadena(ArrayList<ProductoAgregar> productos){
        String CadenaProductos="";
        
        if(productos!=null){
            for(ProductoAgregar producto: productos){
                CadenaProductos = CadenaProductos+producto.getName()+":"+producto.getCantidad()+",";
            }
        }
        
        return CadenaProductos;
        
    }
}
