/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

// Web servlet para comprobar el usuario en el inicio de sesion
@WebServlet(name = "ComprobarUsuario", urlPatterns = "/ComprobarUsuario")
public class ComprobarUsuario extends HttpServlet{
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String tipo =request.getParameter("TipoDeUsuario");
        String usuario = request.getParameter("Nombre");
        String Contraseña = request.getParameter("Contrasena");
        try {
            if(ComprobarUsuarioDB.ExisteUsusario(usuario,tipo)){
                if(ComprobarUsuarioDB.ComprobarContraseña(usuario,Contraseña,tipo)){
                    switch (tipo) {
                        case "Administrador":
                            response.sendRedirect(String.format("JSP/ModuloAdministrador.jsp?usuario=%s",usuario));
                            break;
                        case "Supervisor":
                            response.sendRedirect(String.format("JSP/ModuloSupervisor.jsp?usuario=%s",usuario));
                            break;
                        case "Bodega":
                            response.sendRedirect(String.format("JSP/ModuloBodegaCentral.jsp?usuario=%s",usuario));
                            break;
                        case "Tienda":
                            response.sendRedirect(String.format("JSP/ModuloTienda.jsp?usuario=%s",usuario));
                            break;
                        default:
                            break;
                    }
                    
                }else{
                    response.sendRedirect(String.format("JSP/respuestaAccion.jsp?result=%s&errorMsg=&error=true", "Contraseña Incorrecta"));
                }
            }else{
               response.sendRedirect(String.format("JSP/respuestaAccion.jsp?result=%s&errorMsg=&error=true", "Usuario Inexistente")); 
            }
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ComprobarUsuario.class.getName()).log(Level.SEVERE, null, ex);
            System.out.print(ex);
        }   
    }    
}
