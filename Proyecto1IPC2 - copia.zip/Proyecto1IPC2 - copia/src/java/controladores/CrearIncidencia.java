/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Modelos.Incidencia;
import Modelos.Pedidos;
import Modelos.ProductoAgregar;
import Modelos.Productos;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "CrearIncidencia", urlPatterns = "/CrearIncidencia")
public class CrearIncidencia extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response){
        try {
            String producto = request.getParameter("Productos");
            String Usuario = request.getParameter("usuario");
            String id = request.getParameter("id");
            String[] productos = producto.split(",");
            ArrayList<ProductoAgregar> ProductoLista = new ArrayList<>();
            for(int x=0; x<productos.length; x++){
                System.out.println(productos[x]);
                String[] productosCantidades = productos[x].split(":");
                if(productosCantidades.length>2){
                    System.out.println(productosCantidades[0]);
                    ProductoAgregar productoSg = new ProductoAgregar(productosCantidades[0],Integer.parseInt(productosCantidades[1]),productosCantidades[2]);
                    ProductoLista.add(productoSg);
                }
            }
            int tienda = BuscarDB.BuscarTiendaDeUsuario(Usuario);
            
            Incidencia incidencia = new Incidencia(BuscarId(),String.valueOf(tienda),ProductoLista,"activa",id);
            response.sendRedirect(String.format("JSP/RespuestaTienda.jsp?result=%s&usuario=%s",Escritor.EscritorIncidencia(incidencia),Usuario)); 
        } catch (SQLException | ClassNotFoundException | IOException ex) {
            Logger.getLogger(CrearPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private int BuscarId(){
        for(int i = 1;i>0; i++){
            System.out.println("Entra al for"+i);
            if(ComprobarSiExiste.ComprobarIncidencia(i)){
                
            } else {
                return i;
            }
        }
        return 0;
    }
}
