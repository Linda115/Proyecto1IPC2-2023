/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Modelos.Productos;
import Modelos.Pedidos;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "CrearPedido", urlPatterns = "/CrearPedido")
public class CrearPedido extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response){
        try {
            String pedidos = request.getParameter("Productos");
            String Usuario = request.getParameter("usuario");
            String[] productos = pedidos.split(",");
            HashMap<String, String> ProductosLista = new HashMap<String, String>();
            for(int x=0; x<productos.length; x++){
                System.out.println(productos[x]);
                String[] productosCantidades = productos[x].split(":");
                if(productosCantidades.length>1){
                    System.out.println(productosCantidades[0]);
                    ProductosLista.put(productosCantidades[0], productosCantidades[1]);
                }
            }
            ArrayList<Productos> ProductosPedido = new ArrayList<>();
            Productos producto;
            System.out.println(ProductosLista);
            for (Map.Entry<String, String> entry : ProductosLista.entrySet()) {
                try {
                    System.out.println(entry.getKey()+entry.getValue()+" Nombre Producto/n");
                    producto = BuscarDB.BuscarProducto(entry.getKey());
                    if(producto==null){
                        producto = BuscarDB.BuscarProductoNombre(entry.getKey());
                    }
                    producto.setExistencia(entry.getValue());
                    ProductosPedido.add(producto);
                } catch (SQLException | ClassNotFoundException ex) {
                    Logger.getLogger(CrearPedido.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            Double total = 0.0;
            for(Productos producto1: ProductosPedido){
                total= total + producto1.getCosto()*Integer.parseInt(producto1.getExistencia());
            }
            total = Math.round(total * 100) / 100d;
            
            System.out.println(total);
            int tienda = BuscarDB.BuscarTiendaDeUsuario(Usuario);
            String estado;
            if(BuscarDB.BuscarTipoTienda(tienda).equals("supervisada")){
                 estado = "Pendiente";
            }else{
                 estado = "Solicictado";
            }
            Pedidos pedido = new Pedidos(BuscarId(),tienda,ProductosPedido, total, estado);
            System.out.println(pedido.getProductosCadena());
            response.sendRedirect(String.format("JSP/RespuestaTienda.jsp?result=%s&usuario=%s",Escritor.EscritorPedido(pedido),Usuario)); 
        } catch (SQLException | ClassNotFoundException | IOException ex) {
            Logger.getLogger(CrearPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private int BuscarId(){
        for(int i = 1;i>0; i++){
            System.out.println("Entra al for"+i);
            if(ComprobarSiExiste.ComprobarPedido(i)){
                
            } else {
                return i;
            }
        }
        return 0;
    }
}
