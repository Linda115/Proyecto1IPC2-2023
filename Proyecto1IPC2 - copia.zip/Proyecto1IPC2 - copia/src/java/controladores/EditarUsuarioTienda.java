/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Modelos.UsuarioTienda;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "EditarUsuariotienda", urlPatterns = "/EditarUsuariotienda")
public class EditarUsuarioTienda extends HttpServlet{
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
             {  
                 if(ComprobarSiExiste.ComprobarTienda(request.getParameter("Tienda"))){
                 UsuarioTienda usuarioTienda = new UsuarioTienda(request.getParameter("Codigo"),request.getParameter("Nombre"),request.getParameter("NombreUsuario"),request.getParameter("Contrasena"),request.getParameter("Correo"),request.getParameter("Tienda"));
                
                    try {
                        if(Escritor.EscritorUsuarioTienda(usuarioTienda)){
                            response.sendRedirect(String.format("ModuloAdministrador.html?result=%s&errorMsg=&error=false", "Escribir", ""));
                        } else {
                            response.sendRedirect(String.format("JSP/AlerAdministrador.jsp?result=%s&errorMsg=&error=true", " Algo salio mal, intente de nuevo"));
                        }
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(CrearUsuarioTienda.class.getName()).log(Level.SEVERE, null, ex);
                        response.sendRedirect(String.format("JSP/respuestaAccion.jsp?result=%s&errorMsg=&error=true", " Algo salio mal, intente de nuevo"));
                    }
                   
                }else{
                     response.sendRedirect(String.format("JSP/respuestaAccion.jsp?result=%s&errorMsg=&error=true", " No existe la tienda"));
                 }
    }
    
}
