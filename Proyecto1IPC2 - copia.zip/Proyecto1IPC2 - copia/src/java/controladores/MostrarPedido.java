/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Configuraciones.Conexion;
import Modelos.Estado;
import Modelos.Pedidos;
import Modelos.Productos;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "MostraPedido", urlPatterns = "/MostrarPedido")
public class MostrarPedido extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response){
        try {
            String usuario =request.getParameter("usuario");
            String pedido =request.getParameter("pedido");
            
            response.sendRedirect(String.format("JSP/MostrarPedido.jsp?usuario=%s&pedido="+pedido,usuario));
        } catch (IOException ex) {
            Logger.getLogger(MostrarEnvio.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
