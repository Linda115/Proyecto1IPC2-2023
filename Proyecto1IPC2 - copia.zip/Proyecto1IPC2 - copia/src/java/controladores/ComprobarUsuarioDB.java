/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Configuraciones.Conexion;
import java.sql.*;

/**
 *
 * @author Linda Monterroso
 */

//Controlador para comprobar que existe el usuario en la base de datos
public class ComprobarUsuarioDB {

    private static String tipo;
    private static String database;

    //Controlador para comprobar que existe el usuario en la base de datos
    public static boolean ExisteUsusario(String nombre, String tipo) throws SQLException, ClassNotFoundException {
        ComprobarUsuarioDB.tipo = tipo;
        
        switch (tipo) {
            case "Administrador":
                database = "tienda.usuariosadministradores";
                break;
            case "Tienda":
                database = "tienda.usuariostienda";
                break;
            case "Supervisor":
                database = "tienda.usuariossupervisor";
                break;
            case "Bodega":
                database = "tienda.usuariosbodega";
                break;
            default:
                break;
        }
        
        
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where NombreUsuario=?"
                ,database));
                
                query.setString(1, nombre);
                ResultSet resultado = query.executeQuery();

                
                if(resultado!=null){
                    return true;
                }
                return resultado.next();
                
                  
        } catch (SQLException e) {
            System.out.print(e);
            return false;
        }
    }

    //Controlador para comprobar la contraseña es correcta
    public static boolean ComprobarContraseña(String nombre, String contraseña, String tipo) throws SQLException, ClassNotFoundException {
        ComprobarUsuarioDB.tipo = tipo;
        switch (tipo) {
            case "Administrador":
                database = "tienda.usuariosadministradores";
                break;
            case "Tienda":
                database = "tienda.usuariostienda";
                break;
            case "Supervisor":
                database = "tienda.usuariossupervisor";
                break;
            case "Bodega":
                database = "tienda.usuariosbodega";
                break;
            default:
                break;
        }
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where NombreUsuario=?",database
                ));
                
                query.setString(1, nombre);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String nuevContr = resultado.getString("Contraseña");
                      
                return contraseña.equals(nuevContr);
                  
                }
                return false;
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return false;
        }
    }

    //regresa el tipo del usuario
    public static int getTipo(String nombre, String contraseña) throws SQLException, ClassNotFoundException {
       Conexion coneccionBd = new Conexion();
            
            
        Connection coneccion = coneccionBd.getConexion();

       

        PreparedStatement query = coneccion.prepareStatement(String.format("SELECT * FROM %s Where Nombre = ?", ""));
        query.setString(1, "\"" + nombre + "\"");
        ResultSet resultado = query.executeQuery();
        

        while (resultado.next()) {

            if (resultado.getString("Contraseña").equals(contraseña)) {
                return resultado.getInt("Tipo");
            }
        }
        return 0;
    }

}
