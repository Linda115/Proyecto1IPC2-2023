/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "EliminarUsuarioBodega", urlPatterns = "/EliminarUsuarioBodega")
public class EliminarUsuarioBodega extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
             {  
                 String CodigoUsuario = request.getParameter("NombreUsuario");
                 if(ComprobarSiExiste.ComprobarUsuarioBodega(CodigoUsuario)){
                     try {
                         if(Escritor.EliminarUsaurioBodega(CodigoUsuario)){
                             response.sendRedirect(String.format("Eliminado.html"));
                         }else{
                             response.sendRedirect(String.format("JSP/respuestaAccion.jsp?result=%s&errorMsg=&error=true", " No se pudo eliminar el Usuario"));
                         }
                     } catch (ClassNotFoundException ex) {
                         Logger.getLogger(BuscarUsuarioTiendaEliminar.class.getName()).log(Level.SEVERE, null, ex);
                         response.sendRedirect(String.format("JSP/respuestaAccion.jsp?result=%s&errorMsg=&error=true", " No se pud eliminar el Usuario"));
                     }
                   
                }else{
                     response.sendRedirect(String.format("JSP/respuestaAccion.jsp?result=%s&errorMsg=&error=true", " No existe el Usuario"));
                 }
    }
}
