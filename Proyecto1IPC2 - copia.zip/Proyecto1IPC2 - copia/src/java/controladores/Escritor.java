/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Configuraciones.Conexion;
import Modelos.Devoluciones;
import Modelos.Envio;
import Modelos.Incidencia;
import Modelos.Pedidos;
import Modelos.Tienda;
import Modelos.UsuarioBodega;
import Modelos.UsuarioSupervisor;
import Modelos.UsuarioTienda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Linda Monterroso
 */
public  class Escritor {
    
    private static Connection conexion;
    private static String database;
    /**
     *
     * @param devolucion
     * @return 
     */
    public static boolean EscritorDevolucion(Devoluciones devolucion) throws ClassNotFoundException   {
        database = "tienda.devoluciones";
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement(String.format("INSERT into %s (Id, fecha, productos, total, estado, tienda) VALUES (?, ?, ?, ?, ?, ?)",database));
            ps.setInt(1, devolucion.getID());
            ps.setDate(2, devolucion.getFecha());
            ps.setString(3, devolucion.getProductosCadena());
            ps.setDouble(4, devolucion.getTotal());
            ps.setString(5, devolucion.getEstado().getEstado());
            ps.setString(6, devolucion.getTienda());
            ps.execute();
            return true;
            
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        
    }
    
    public static boolean EscritorEnvio(Envio envio) throws SQLException, ClassNotFoundException{
        database = "tienda.envios";
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement(String.format("INSERT into %s (id, tienda, fechasalida, productos, estado, total) VALUES (?, ?, CURDATE(), ?, ?, ?)",database));
            ps.setInt(1, envio.getID());
            ps.setString(3, envio.getProductosCadena());
            ps.setString(4, envio.getEstado());
            ps.setInt(2, envio.getTienda());
            ps.setDouble(5, envio.getTotal());
            ps.execute();
            return true;
            
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public static boolean EscritorIncidencia(Incidencia incidencia) throws ClassNotFoundException{
        database = "tienda.incidencias";
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement(String.format("INSERT into %s (Id, tienda, fecha, productos, estado, envio) VALUES (?, ?, CURDATE(), ?, ?,?)",database));
            ps.setInt(1, incidencia.getID());
            ps.setString(3, incidencia.getProductosCadena());
            ps.setString(4, incidencia.getEstado());
            ps.setString(2, incidencia.getTienda());
            ps.setString(5, incidencia.getEnvio());
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        
    }
    
    public static boolean EscritorPedido(Pedidos pedido) throws ClassNotFoundException{
        database = "tienda.Pedidos";
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement(String.format("INSERT into %s (id, tienda, fecha, productos, estado, total) VALUES (?, ?, CURDATE(), ?, ?, ?)",database));
            ps.setInt(1, pedido.getID());
            ps.setString(3, pedido.getProductosCadena());
            ps.setString(4, pedido.getEstado());
            ps.setInt(2, pedido.getTienda());
            ps.setDouble(5, pedido.getTotal());
            ps.execute();
            return true;
            
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        
    }
    
    public static boolean EscritorUsuarioTienda(UsuarioTienda usuarioTienda) throws ClassNotFoundException{
      
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("INSERT into tienda.usuariostienda (Codigo, Nombre, Tienda, NombreUsuario, Contraseña, CorreoElectronico) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setString(1, usuarioTienda.getCodigo());
            ps.setString(2, usuarioTienda.getNombre() );
            ps.setString(3, usuarioTienda.getTienda());
            ps.setString(4, usuarioTienda.getNombre_usuario());
            ps.setString(5, usuarioTienda.getContraseña());
            ps.setString(6, usuarioTienda.getCorreo());
            
            ps.execute();
            return true;
            
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        
    }
    
    public static boolean EscritorTienda(Tienda tienda){
        
        return true;
    }
    
    public static boolean EliminarUsaurioTienda(String codigo) throws ClassNotFoundException{
      Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("DELETE from tienda.usuariostienda WHERE Codigo=?");
            ps.setString(1, codigo);
            
            ps.execute();
            return true;
            
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        
    }
   
    public static boolean EscritorUsuarioBodega(UsuarioBodega usuarioBodega) throws ClassNotFoundException{
      
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("INSERT into tienda.usuariosbodega (Codigo, Nombre, NombreUsuario, Contraseña, CorreoElectronico) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, usuarioBodega.getCodigo());
            ps.setString(2, usuarioBodega.getNombre() );
            ps.setString(3, usuarioBodega.getNombre_usuario());
            ps.setString(4, usuarioBodega.getContraseña());
            ps.setString(5, usuarioBodega.getCorreo());
            
            ps.execute();
            return true;
            
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public static boolean EliminarUsaurioBodega(String codigo) throws ClassNotFoundException{
      Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("DELETE from tienda.usuariosbodega WHERE Codigo=?");
            ps.setString(1, codigo);
           
          ps.execute();
          return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
         
    }
    
    public static boolean EscritorUsuariSupervisor(UsuarioSupervisor usuarioSupervisor) throws ClassNotFoundException{
      
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("INSERT into tienda.usuariossupervisor (Codigo, Nombre, NombreUsuario, Contraseña, CorreoElectronico) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, usuarioSupervisor.getCodigo());
            ps.setString(2, usuarioSupervisor.getNombre() );
            ps.setString(3, usuarioSupervisor.getNombre_usuario());
            ps.setString(4, usuarioSupervisor.getContraseña());
            ps.setString(5, usuarioSupervisor.getCorreo());
            
            ps.execute();
            return true;
            
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public static boolean EliminarUsaurioSupervisor(String codigo) throws ClassNotFoundException{
      Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("DELETE from tienda.usuariossupervisor WHERE Codigo=?");
            ps.setString(1, codigo);
           
          ps.execute();
          return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
         
    }
    
    public static boolean BuscarProducto(String NombreProducto) throws SQLException, ClassNotFoundException{
        
        Conexion con = new Conexion();
        conexion = con.getConexion();
        
        PreparedStatement ps;
        ps = conexion.prepareStatement("");
        
        return true;
    }
    
    public static boolean EditarCatalogo(int tienda, String Productos) throws ClassNotFoundException{
        
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement("UPDATE tienda.catalogos SET Productos=? WHERE tienda=?");
            ps.setString(1, Productos);
            ps.setInt(2, tienda);
           
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public static boolean CAmbiarEstadoEnvio(int id) throws ClassNotFoundException{
        database = "tienda.envios";
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement(String.format("UPDATE %s SET estado='recibido', fecharecibida=CURDATE() WHERE ID=?",database));
            ps.setInt(1, id);
           
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public static boolean CAmbiarEstadoPedido(int id) throws ClassNotFoundException{
        database = "tienda.pedidos";
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement(String.format("UPDATE %s SET estado=\"Enviado\" WHERE ID=?",database));
            ps.setInt(1, id);
           
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public static boolean CambiarEstadoPedidoSupervisor(int id,String estado) throws ClassNotFoundException{
        database = "tienda.pedidos";
        Conexion con = new Conexion();
        try {
            conexion = con.getConexion();
        } catch (SQLException ex) {
            Logger.getLogger(Escritor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PreparedStatement ps;
        try{
            ps = conexion.prepareStatement(String.format("UPDATE %s SET estado=? WHERE ID=?",database));
            ps.setString(1, estado);
            ps.setInt(2, id);
           
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
}
