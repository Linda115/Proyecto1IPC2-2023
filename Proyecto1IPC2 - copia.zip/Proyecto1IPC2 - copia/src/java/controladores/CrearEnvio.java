/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Modelos.Envio;
import Modelos.Estado;
import Modelos.Pedidos;
import Modelos.Productos;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "CrearEnvio", urlPatterns = "/CrearEnvio")
public class CrearEnvio extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
        try {
            String envio = request.getParameter("cadenaProductos");
            String Usuario = request.getParameter("usuario");
            String pedido = request.getParameter("pedido");
            String[] productos = envio.split(",");
            HashMap<String, String> ProductosLista = new HashMap<String, String>();
            for(int x=0; x<productos.length; x++){
                System.out.println(productos[x]);
                String[] productosCantidades = productos[x].split(":");
                if(productosCantidades.length>1){
                    System.out.println(productosCantidades[0]);
                    ProductosLista.put(productosCantidades[0], productosCantidades[1]);
                }
            }
            ArrayList<Productos> ProductosPedido = new ArrayList<>();
            Productos producto;
            System.out.println(ProductosLista);
            for (Map.Entry<String, String> entry : ProductosLista.entrySet()) {
                try {
                    System.out.println(entry.getKey()+entry.getValue()+" Nombre Producto/n");
                    producto = BuscarDB.BuscarProducto(entry.getKey());
                    if(producto==null){
                        producto = BuscarDB.BuscarProductoPorNombre(entry.getKey());
                    }
                    producto.setExistencia(request.getParameter("cantidad"+producto.getCodigo()));
                    ProductosPedido.add(producto);
                } catch (SQLException | ClassNotFoundException ex) {
                    Logger.getLogger(CrearPedido.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            Double total = 0.0;
            Productos productobodega;
            ArrayList<Productos> ProductosPedidoNuevo = new ArrayList<>();
            for(Productos producto1: ProductosPedido){
                productobodega = BuscarDB.BuscarProductoExistenciaBodega(producto1.getCodigo());
                System.out.println(productobodega.getExistencia());
                if(Integer.parseInt(productobodega.getExistencia())<Integer.parseInt(producto1.getExistencia())){
                    producto1.setExistencia(productobodega.getExistencia());
                }
                ProductosPedidoNuevo.add(producto1);
            }
            
            for(Productos producto1: ProductosPedido){
                total= total + producto1.getCosto()*Integer.parseInt(producto1.getExistencia());
            }
            total = Math.round(total * 100) / 100d;
            
            System.out.println(total);
            
            Envio envios = new Envio(BuscarId(),BuscarDB.BuscarTiendaPedido(Integer.parseInt(pedido)),ProductosPedidoNuevo,"Despachado",total);
            response.sendRedirect(String.format("JSP/RespuestaBodega.jsp?result=%s&usuario=%s",Escritor.EscritorEnvio(envios)&&Escritor.CAmbiarEstadoPedido(Integer.parseInt(pedido)),Usuario)); 
        } catch (SQLException | ClassNotFoundException  ex) {
            Logger.getLogger(CrearPedido.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private int BuscarId(){
        for(int i = 2;i>0; i++){
            System.out.println("Entra al for"+i);
            if(!ComprobarSiExiste.ComprobarPedido(i)){
                System.out.println("Entra al if"+i);
            } else {
                System.out.println("Entra al else"+i);
                return i;
            }
        }
        return 0;
    }
  
}
