/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Configuraciones.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Linda Monterroso
 */

//Controlador para comprobar que exista en la base de datos de distintos 
public class ComprobarSiExiste {
    
    private static String database;
   
    //clase para comprobar que exista la tienda
    public static boolean ComprobarTienda(String Codigo){
        database = "tienda.tiendas";
             
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where Codigo=?",database
                ));
                
                query.setString(1, Codigo);
                ResultSet resultado = query.executeQuery();

                
                if(resultado!=null){
                    return true;
                }
                return resultado.next();
                
                  
        } catch (SQLException e) {
            System.out.print(e);
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ComprobarSiExiste.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
 
    }
    
    // Controlador para comprobar que exista el usuario de tipo tienda
   public static boolean ComprobarUsuarioTienda(String CodigoUusario){
        database ="tienda.usuariostienda";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where Codigo=?",database
                ));
                
                query.setString(1, CodigoUusario);
                ResultSet resultado = query.executeQuery();

                
                if(resultado!=null){
                    return true;
                }
                return resultado.next();
                
                  
        } catch (SQLException e) {
            System.out.print(e);
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ComprobarSiExiste.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
 
    } 
   
   //Controlador par acomprobar que exista el usuario de tipo bodega
   public static boolean ComprobarUsuarioBodega(String CodigoUusario){
        database = "tienda.usuariosbodega";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where Codigo=?",database
                ));
                
                query.setString(1, CodigoUusario);
                ResultSet resultado = query.executeQuery();

                
                if(resultado!=null){
                    return true;
                }
                return resultado.next();
                
                  
        } catch (SQLException e) {
            System.out.print(e);
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ComprobarSiExiste.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
 
    } 
   
   //Controlador para comprobar que exista el usuario de tipo supervisor
    public static boolean ComprobarUsuarioSupervisor(String CodigoUusario){
        database = "tienda.usuariossupervisor";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where Codigo=?",database
                ));
                
                query.setString(1, CodigoUusario);
                ResultSet resultado = query.executeQuery();

                
                if(resultado!=null){
                    return true;
                }
                return resultado.next();
                
                  
        } catch (SQLException e) {
            System.out.print(e);
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ComprobarSiExiste.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
 
    }
    
    //Comprobar si existe el pedido en la base de datos
    public static boolean ComprobarPedido(int id){
        database = "tienda.pedidos";
        try {
            Conexion coneccionBd = new Conexion();
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where id=?",database
                ));
            query.setInt(1, id);
            ResultSet resultado = query.executeQuery();

            return resultado.next();
                  
        } catch (SQLException e) {
            System.out.print(e);
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ComprobarSiExiste.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
 
    }
   
    //Comprobar si existe la incidencia en la base de datos
    public static boolean ComprobarIncidencia(int id){
        database = "tienda.incidencias";
        try {
            Conexion coneccionBd = new Conexion();
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where id=?",database
                ));
            query.setInt(1, id);
            ResultSet resultado = query.executeQuery();
  
            return resultado.next();
                  
        } catch (SQLException e) {
            System.out.print(e);
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ComprobarSiExiste.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
}
