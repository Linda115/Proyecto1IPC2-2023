/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "AgregarAlEnvio", urlPatterns = "/AgregarAlEnvio")
public class AgregarAlEnvio extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        String nombreProducto = request.getParameter("Productos");
        System.out.println(nombreProducto);
        String productosagregar = request.getParameter("productosagregar");
        String Nombre = request.getParameter("usuario");
        String Cantidad = request.getParameter("cantidad");
        String pedido = request.getParameter("Pedido");
        if(productosagregar!=null){
            if(!productosagregar.equals("null")){
            productosagregar = productosagregar+nombreProducto+":"+Cantidad+",";
            }else{
            productosagregar = nombreProducto+":"+Cantidad+",";
            System.out.println("entro else");
        }
            System.out.println("entro if");
        }else{
            productosagregar = nombreProducto+":"+Cantidad+",";
            System.out.println("entro else");
        }
        System.out.println(productosagregar);
        response.sendRedirect(String.format("JSP/MostrarPedido.jsp?usuario="+Nombre+"&nombreProducto=null&productosagregar="+productosagregar+"&pedido="+pedido));
        
    }
    
}
