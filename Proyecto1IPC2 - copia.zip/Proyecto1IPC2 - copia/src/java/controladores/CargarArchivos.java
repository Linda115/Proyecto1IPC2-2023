/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
/**
 *
 * @author Linda Monterroso
 */

@MultipartConfig
@WebServlet(name = "CargarArchivos", urlPatterns = "/CargarArchivos")
public class CargarArchivos extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final String pathFiles = "http://localhost:8081/Proyecto1IPC2/Json/";
    private File uploads = new File(pathFiles);
    private final String extens = ".JSON";
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
       saveCustomer(request,response);
    }
    
    private void saveCustomer(HttpServletRequest request, HttpServletResponse response) throws IOException{
        try {
            String usuario = request.getParameter("usuario");
            Part part = request.getPart("file");
            
            if(part == null){
                System.out.println("No se ha seleccionado un archivo");
                return;
            }
            
            if(isExtension(part.getSubmittedFileName(), extens)){
                String ruta = saveFile(part, uploads);
                
            }
        } catch (ServletException ex) {
            Logger.getLogger(CargarArchivos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private String saveFile(Part part, File pathUploads){
        String pathAbsolute = "";
        
        try{
            Path path = Paths.get(part.getSubmittedFileName());
            String fileName = path.getFileName().toString();
            InputStream input = part.getInputStream();
            
            if(input != null){
                File file = new File(pathUploads,fileName);
                pathAbsolute = file.getAbsolutePath();
                Files.copy(input, file.toPath());
                
            }
        }catch(IOException e){
            System.out.println(e);
        }
        return pathAbsolute;
    }
    
    private boolean isExtension(String fileName,String extensions ){
        if(fileName.toLowerCase().endsWith(extensions)){
            return true;
        }
        return false;
    }
}
