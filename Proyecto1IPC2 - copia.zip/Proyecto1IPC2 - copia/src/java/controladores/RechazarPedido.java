/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

@WebServlet(name = "RechazarPedido", urlPatterns = "/RechazarPedido")
public class RechazarPedido extends HttpServlet {
    
      @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
         try {
             String usuario = request.getParameter("usuario");
             String Pedido = request.getParameter("Pedido");
             
             response.sendRedirect(String.format("JSP/RespuestaSupervisor.jsp?result=%s&usuario="+usuario, Escritor.CambiarEstadoPedidoSupervisor(Integer.parseInt(Pedido), "rechazado")));
         } catch (ClassNotFoundException ex) {
             Logger.getLogger(AprobarPedido.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    
}
