/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Configuraciones.Conexion;
import Modelos.Productos;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Linda Monterroso
 */

//Controlador para buscar objetos en la base de datos
public class BuscarDB {
    
    //nuestra base de datos dependiendo de la clase
    private static String database ;
    
    //Nos retorna el producto para ver su existencia en bodega 
    public static Productos BuscarProductoExistenciaBodega(String nombre) throws SQLException, ClassNotFoundException {
        Productos producto;
        database = "tienda.catalogobodega";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where CodigoProducto=?",database
                ));
                
                query.setString(1, nombre);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String codigo = resultado.getString("CodigoProducto");
                    String nombr = resultado.getString("nombre");
                    Double costo = resultado.getDouble("costo");
                    String existencia = resultado.getString("existencias");
                    producto = new Productos(codigo,nombr,costo,existencia);
                    return producto;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //Busca los productos de la bodega, devuelve el producto
    public static Productos BuscarProducto(String codigoP) throws SQLException, ClassNotFoundException {
        Productos producto;
        database = "tienda.catalogobodega";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where CodigoProducto=?",database
                ));
                
                query.setString(1, codigoP);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String codigo = resultado.getString("CodigoProducto");
                    String nombr = resultado.getString("nombre");
                    Double costo = resultado.getDouble("costo");
                  
                    producto = new Productos(codigo,nombr,costo);
                    return producto;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    public static Productos BuscarProductoNombre(String nombre) throws SQLException, ClassNotFoundException {
        Productos producto;
        database = "tienda.catalogobodega";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where Nombre=?",database
                ));
                
                query.setString(1, nombre);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String codigo = resultado.getString("CodigoProducto");
                    String nombr = resultado.getString("nombre");
                    Double costo = resultado.getDouble("costo");
                  
                    producto = new Productos(codigo,nombr,costo);
                    return producto;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    public static Productos BuscarProductoPorNombre(String nombre) throws SQLException, ClassNotFoundException {
        Productos producto;
        database = "tienda.catalogobodega";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where Nombre=?",database
                ));
                
                query.setString(1, nombre);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String codigo = resultado.getString("CodigoProducto");
                    String nombr = resultado.getString("nombre");
                    Double costo = resultado.getDouble("costo");
                  
                    producto = new Productos(codigo,nombr,costo);
                    return producto;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //Busca los productos de la tienda, devuelve el producto
    public static Productos BuscarProductosTienda(String nombre, String tienda) throws SQLException, ClassNotFoundException {
        Productos producto;
        database = "tienda.productos";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where Nombre=?",database
                ));
                
                query.setString(1, nombre);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String codigo = resultado.getString("codigo");
                    String nombr = resultado.getString("nombre");
                    Double costo = resultado.getDouble("costo");
                  
                    producto = new Productos(codigo,nombr,costo);
                    return producto;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //busca los pedidos de la tienda, devuelve el producto
    public static String BuscarPedido(int id) throws SQLException, ClassNotFoundException {
        
        database = "tienda.pedidos";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where id=?",database
                ));
                
                query.setInt(1, id);
                
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String producto = resultado.getString("productos");
                  
                    return producto;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //busca la tienda segun el usuario, devuelve id de la tienda
    public static int BuscarTiendaDeUsuario(String nombre) throws SQLException, ClassNotFoundException {
        database = "tienda.usuariostienda";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where NombreUsuario=?",database
                ));
                
                query.setString(1, nombre);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    int tienda = resultado.getInt("Tienda");
                    return tienda;
                }else{
                    return 0;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return 0;
        }
    }
    
    //busca los envios de la tienda solo devuelve los id
    public static ResultSet BuscarEnvios(int tienda) throws SQLException, ClassNotFoundException {
        database = "tienda.envios";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where tienda=? AND estado=\"despachado\" ",database
                ));
                
                query.setInt(1, tienda);
                ResultSet resultado = query.executeQuery();
                return resultado;
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //busca los envios de la tienda solo devuelve los id
    public static ResultSet BuscarEnviosRecibidos(int tienda) throws SQLException, ClassNotFoundException {
        database = "tienda.envios";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where tienda=? AND estado=\"recibidos\" ",database
                ));
                
                query.setInt(1, tienda);
                ResultSet resultado = query.executeQuery();
                return resultado;
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //busca el envio segun el id, devuelve los productos
    public static String getEnvios(int id) throws SQLException, ClassNotFoundException {
        database = "tienda.envios";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where id=? ",database
                ));
                
                query.setInt(1, id);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String Productos = resultado.getString("productos");
                    return Productos;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    
    public static String getCatalogo(int tienda){
        database = "tienda.catalogos";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where tienda=? ",database
                ));
                
                query.setInt(1, tienda);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String Productos = resultado.getString("productos");
                    return Productos;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BuscarDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    //busca el tipo de tienda segun el id de la tienda
    public static String BuscarTipoTienda(int tienda) throws SQLException, ClassNotFoundException {
        database = "tienda.tiendas";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where codigo=?",database
                ));
                
                query.setInt(1, tienda);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String tipo = resultado.getString("tipo");
                    return tipo;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //Busca la lista de tiendas a la que tiene a cargo el supervisor
    public static String BuscarTiendasDeBodega(String bodega) throws SQLException, ClassNotFoundException {
        database = "tienda.usuariosbodega";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where nombreusuario=?",database
                ));
                
                query.setString(1, bodega);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String cadena = resultado.getString("TiendasSupervisadas");
                    return cadena;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    //Busca los pedidos segun la tienda
    public static ResultSet BuscarPedidos(int tienda) throws SQLException, ClassNotFoundException {
        database = "tienda.pedidos";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where tienda=? AND estado=\"Solicictado\" ",database
                ));
                
                query.setInt(1, tienda);
                ResultSet resultado = query.executeQuery();
                return resultado;
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    /**
     *
     * @param id
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public static int BuscarTiendaPedido(int id) throws SQLException, ClassNotFoundException {
        
        database = "tienda.pedidos";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where id=?",database
                ));
                
                query.setInt(1, id);
                Date fecha;
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    int tienda = Integer.parseInt(resultado.getString("tienda"));
                  
                    return tienda;
                }else{
                    return 0;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return 0;
        }
    }
    
    //Buscar envios para incidencia o devolucion 
    public static Boolean BuscarEnvio(int id, String usuario) throws SQLException, ClassNotFoundException {
        
        database = "tienda.envios";
        int tienda;
        tienda = BuscarTiendaDeUsuario(usuario);
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where id=? AND estado='recibido' AND tienda=? ",database
                ));
                
                query.setInt(1, id);
                query.setInt(2, tienda);
                ResultSet resultado = query.executeQuery();
                
                
            return resultado.next();
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return false;
        }
    }
    
    //Buscar pedidos pendientes de revision del supervisor
    public static ResultSet BuscarPedidosSupervisados(int tienda) throws SQLException, ClassNotFoundException {
        database = "tienda.pedidos";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where tienda=? AND estado=\"Pendiente\" ",database
                ));
                
                query.setInt(1, tienda);
                ResultSet resultado = query.executeQuery();
                return resultado;
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
    public static String BuscarTiendasDeSupervisor(String supervisor) throws SQLException, ClassNotFoundException {
        database = "tienda.usuariossupervisor";
        try {
            Conexion coneccionBd = new Conexion();
            
            
            Connection coneccion = coneccionBd.getConexion();
            
            PreparedStatement query;
                query = coneccion.prepareStatement(String.format(
                        "SELECT * FROM %s where nombreusuario=?",database
                ));
                
                query.setString(1, supervisor);
                ResultSet resultado = query.executeQuery();
                if(resultado.next()){
                    String cadena = resultado.getString("TiendasSupervisadas");
                    return cadena;
                }else{
                    return null;
                }
        } catch (SQLException e) {
            System.out.print(e);
            System.out.println("Error en la coneccion");
            return null;
        }
    }
    
}
