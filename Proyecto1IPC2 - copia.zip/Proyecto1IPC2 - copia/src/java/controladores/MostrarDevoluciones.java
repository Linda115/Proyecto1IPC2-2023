/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import Configuraciones.Conexion;
import Modelos.Devoluciones;
import Modelos.Estado;
import Modelos.Productos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Linda Monterroso
 */
public class MostrarDevoluciones {
    
    Connection conexion;
    
    public MostrarDevoluciones() throws SQLException{
        Conexion con = new Conexion();
        conexion = con.getConexion();
    }
    
    public List<Devoluciones> MostrarDevoluciones(String tienda, Date fecha, Date fehca2) {
       
        PreparedStatement ps;
        ResultSet rs;
        List<Devoluciones> devoluciones = new ArrayList<>();
        
        try{
            ps = conexion.prepareStatement("SELECT Id, tienda, fecha, listado, total, estado FROM Devoluciones  ");
            rs = ps.executeQuery();
            
            while(rs.next()){
            
            int id = rs.getInt("Id");
            String tiend = rs.getString("tienda");
            Date fech = rs.getDate("fecha");
            String lista = rs.getString("listado");
            Double total = rs.getDouble("total");
            Productos[] productos = null;
            Estado estado = null;
            Devoluciones devolucion = new Devoluciones(id,tiend, (java.sql.Date) fech, productos,  total,  estado);
            
            devoluciones.add(devolucion);
        }
            return devoluciones;
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
        }
        
    }
}
