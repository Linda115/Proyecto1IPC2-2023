/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Linda Monterroso
 */

//Web Servlet para buscar un producto 
@WebServlet(name = "BuscarEnvio", urlPatterns = "/BuscarEnvio")
public class BuscarEnvio extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String Nombre = request.getParameter("usuario");
            
            if(BuscarDB.BuscarEnvio(id,Nombre)){
                response.sendRedirect(String.format("JSP/CrearIncidencia.jsp?usuario="+Nombre+"&id="+id));
            }else{
                response.sendRedirect(String.format("JSP/CrearIncidencia.jsp?usuario="+Nombre));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(BuscarEnvio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BuscarEnvio.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}