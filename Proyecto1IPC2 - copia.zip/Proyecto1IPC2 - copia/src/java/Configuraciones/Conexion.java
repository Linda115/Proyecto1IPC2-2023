/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Configuraciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Linda Monterroso
 */
public class Conexion {
    
    public Connection getConexion() throws SQLException, ClassNotFoundException{
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");  
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/tienda","root", "12345678" );
            return conexion;
        } catch(SQLException e){
            System.out.println(e.toString());
            return null;
        }
        
    }
}
