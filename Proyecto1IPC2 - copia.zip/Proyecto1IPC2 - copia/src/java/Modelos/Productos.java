/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;


/**
 *
 * @author Linda Monterroso
 */

//Modelo de productos
public class Productos {
    
    private String codigo, Nombre;
    private Double Costo;
    private String Existencia;
    
    public Productos(String codigo, String Nombre, Double Costo, String existencia){
        this.codigo = codigo;
        this.Nombre = Nombre;
        this.Costo = Costo;
        this.Existencia = existencia;
    }
    
    public Productos(String codigo, String Nombre, Double Costo){
        this.codigo = codigo;
        this.Nombre = Nombre;
        this.Costo = Costo;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre_Usuario) {
        this.Nombre = Nombre_Usuario;
    }

    public double getCosto() {
        return Costo;
    }

    public void setCosto(double Costo) {
        this.Costo = Costo;
    }

    public String getExistencia() {
        return Existencia;
    }

    public void setExistencia(String Existencia) {
        this.Existencia = Existencia;
    }   
    
}
