/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.sql.Date;
import java.util.ArrayList;

/**
 *
 * @author Linda Monterroso
 */

//Modelo de envio
public class Envio {
    
    private int ID;
    private int tienda;
    private Date fechaSalida;
    private Date fechaEntrada;
    private ArrayList<Productos> Productos;
    private String Estado;
    private Double total;

    public Envio(int ID, int tienda, Date fechaSalida, Date fechaEntrada, ArrayList<Productos> Productos, String Estado, Double total) {
        this.ID = ID;
        this.tienda = tienda;
        this.fechaSalida = fechaSalida;
        this.fechaEntrada = fechaEntrada;
        this.Productos = Productos;
        this.Estado = Estado;
        this.total = total;
    }
    
    public Envio(int ID, int tienda, ArrayList<Productos> Productos, String Estado, Double total) {
        this.ID = ID;
        this.tienda = tienda;
        this.Productos = Productos;
        this.Estado = Estado;
        this.total = total;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getTienda() {
        return tienda;
    }

    public void setTienda(int tienda) {
        this.tienda = tienda;
    }

    public Date getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(Date fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public Date getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(Date fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public ArrayList<Productos> getProductos() {
        return Productos;
    }

    public void setProductos(ArrayList<Productos> Productos) {
        this.Productos = Productos;
    }
    
    public String getProductosCadena(){
        String cadena="";
        for(Productos producto:Productos ){
            cadena = cadena+","+producto.getCodigo()+":"+producto.getExistencia();
        }
        return cadena;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }
    
    
    
}
