/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Linda Monterroso
 */

//Modelo de tienda
public class Tienda {
    
    private Catalogo catalogo;
    private String codigo, direccion, tipoTienda;
    private Pedidos[] pedidos;
    private Devoluciones[] devoluciones;

    public Pedidos[] getPedidos() {
        return pedidos;
    }

    public void setPedidos(Pedidos[] pedidos) {
        this.pedidos = pedidos;
    }

    public Devoluciones[] getDevoluciones() {
        return devoluciones;
    }

    public void setDevoluciones(Devoluciones[] devoluciones) {
        this.devoluciones = devoluciones;
    }

    public Incidencia[] getInerencias() {
        return inerencias;
    }

    public void setInerencias(Incidencia[] inerencias) {
        this.inerencias = inerencias;
    }
    private Incidencia[] inerencias;
    
    public Tienda(Catalogo catalogo, String codigo, String direccion, String tipoTienda) {
        this.catalogo = catalogo;
        this.codigo = codigo;
        this.direccion = direccion;
        this.tipoTienda = tipoTienda;
    }

    public Catalogo getCatalogo() {
        return catalogo;
    }

    public void setCatalogo(Catalogo catalogo) {
        this.catalogo = catalogo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTipoTienda() {
        return tipoTienda;
    }

    public void setTipoTienda(String tipoTienda) {
        this.tipoTienda = tipoTienda;
    }
   
    
}
