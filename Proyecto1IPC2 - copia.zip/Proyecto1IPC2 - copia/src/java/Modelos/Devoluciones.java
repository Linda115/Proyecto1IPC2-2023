/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.sql.Date;

/**
 *
 * @author Linda Monterroso
 */

//Modelo de devoluciones
public class Devoluciones {
    
    private int ID;
    private Date fecha;
    private Productos[] productos;
    private Double total;
    private Estado estado;
    private String tienda;

    public Devoluciones(int ID, String tienda, Date fecha, Productos[] productos, Double total, Estado estado) {
        this.ID = ID;
        this.fecha = fecha;
        this.productos = productos;
        this.total = total;
        this.estado = estado;
        this.tienda = tienda;
    }

    public String getProductosCadena(){
        return null;
    }

    public String getTienda() {
        return tienda;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Productos[] getProductos() {
        return productos;
    }

    public void setProductos(Productos[] productos) {
        this.productos = productos;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    
}
