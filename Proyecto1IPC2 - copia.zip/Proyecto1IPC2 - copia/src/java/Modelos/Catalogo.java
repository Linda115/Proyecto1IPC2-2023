/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Linda Monterroso
 */

//Modelo de catalogo
public class Catalogo {
    
    private Productos[] productos;

    public Catalogo(Productos[] productos) {
        this.productos = productos;
    }

    public Productos[] getProductos() {
        return productos;
    }

    public void setProductos(Productos[] productos) {
        this.productos = productos;
    }
    
    
}
