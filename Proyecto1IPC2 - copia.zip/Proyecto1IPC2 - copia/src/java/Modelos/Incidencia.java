/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.sql.Date;
import java.util.ArrayList;

/**
 *
 * @author Linda Monterroso
 */

//Modelo de inerencias
public class Incidencia {
    
    private int ID;
    private ArrayList<ProductoAgregar> productos;
    private String estado;
    private String tienda;
    private String envio;

    public Incidencia(int ID, String tienda, ArrayList<ProductoAgregar> productos, String estado, String envio) {
        this.ID = ID;
        this.productos = productos;
        this.estado = estado;
        this.tienda = tienda;
        this.envio = envio;
    }

    public String getEnvio() {
        return envio;
    }

    public void setEnvio(String envio) {
        this.envio = envio;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public ArrayList<ProductoAgregar> getProductos() {
        return productos;
    }
    
    public String getProductosCadena(){
        String cadena = null;
        
        for(ProductoAgregar producto: productos ){
            if(cadena==null){
                cadena = producto.getName()+":"+producto.getCantidad()+":"+producto.getMotivo()+",";
            }else{
                cadena = cadena+ producto.getName()+":"+producto.getCantidad()+":"+producto.getMotivo()+",";
            }
        }
        return cadena;
        
    }

    public String getTienda() {
        return tienda;
    }

    public void setTienda(String tienda) {
        this.tienda = tienda;
    }

    public void setProductos( ArrayList<ProductoAgregar> productos) {
        this.productos = productos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
}
