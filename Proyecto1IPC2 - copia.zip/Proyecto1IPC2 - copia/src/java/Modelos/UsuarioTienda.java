/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Linda Monterroso
 */

//Modelo de usuarios tiendas
public class UsuarioTienda extends Usuario {
    private String tienda;
    
    public UsuarioTienda(String codigo, String nombre, String nombre_usuario, String contraseña, String correo, String tienda) {
        super(codigo, nombre, nombre_usuario, contraseña, correo);
        this.tienda = tienda;
    }

    public String getTienda() {
        return tienda;
    }

    public void setTienda(String tienda) {
        this.tienda = tienda;
    }
    
    
}
