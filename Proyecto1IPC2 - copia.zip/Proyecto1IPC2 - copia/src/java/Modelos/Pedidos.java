/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.sql.Date;
import java.util.ArrayList;

/**
 *
 * @author Linda Monterroso
 */

//Modelo de pedidos
public class Pedidos {
    
    private int ID;
    private int tienda;
    private Date fecha;
    private ArrayList<Productos> productos;
    private Double total;
    private String estado;

    public Pedidos(int ID, int tienda,Date fecha, ArrayList<Productos> productos, Double total, String estado) {
        this.ID = ID;
        this.tienda = tienda;
        this.fecha = fecha;
        this.productos = productos;
        this.total = total;
        this.estado = estado;
    }
    
    public Pedidos(int ID, int tienda, ArrayList<Productos> productos, Double total, String estado) {
        this.ID = ID;
        this.tienda = tienda;
        this.productos = productos;
        this.total = total;
        this.estado = estado;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public ArrayList<Productos> getProductos() {
        return productos;
    }
    
    public String getProductosCadena(){
        String cadena="";
        for(Productos producto:productos ){
            cadena = cadena+","+producto.getCodigo()+":"+producto.getExistencia();
        }
        return cadena;
    }

    public void setProductos(ArrayList<Productos> productos) {
        this.productos = productos;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getTienda() {
        return tienda;
    }

    public void setTienda(int tienda) {
        this.tienda = tienda;
    }
    
}
